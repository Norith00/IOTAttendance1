var username;
var password;
let wrong = false;

//username = window.prompt("What's your user name?");

document.getElementById("btn").onclick = function(){
    username = document.getElementById("box1").value;
    password = document.getElementById("box2").value;
    //document.getElementById("h1").textContent = `Hello ${username}`;
    
    if(username == 'NPIC01' && password == '123')
    {
        
        //window.alert("Success");
        window.location.assign("page2.html");
        console.log(username);
        console.log(password);
    }
    else if(username == '')
    {
        document.getElementById("p1").textContent = `Please Fill your username`;
    }
    else if(password == '')
    {
        document.getElementById("p1").textContent = `Please fill your password`;
    }
    else
    {
        document.getElementById("p1").textContent = `incorrect password`
        //console.log(wrong);
    }
}
